package fr.banque;

public interface ICompteASeuilRemunere extends ICompteRemunere, ICompteASeuil {

}
